<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class='sideboard'>
        <a href='index.php'>Home</a>
        <a>Profile</a>
        <a href='upload_recipe.php'>Upload Recipe</a>
        <a href='manage_recipe.php'>Manage Recipes</a>
        <a href='logout.php'>Log out</a>
    </div>
</body>
</html>