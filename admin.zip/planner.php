<?php
include 'connection.php';

?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body >
    <?php
    include 'navbar.php';
    ?>
    <div class="first-container">
        
        <div class="fader"></div>
        <div class="home-text">
            <div>Meal Planning For A Healthier Life</div> 
            <button class="get-started">Plan Meals</button>
         </div>
        <img class="bg1" src="healthy+food+for+seniors.jpg" alt="">   
    </div>
</body>
</html>